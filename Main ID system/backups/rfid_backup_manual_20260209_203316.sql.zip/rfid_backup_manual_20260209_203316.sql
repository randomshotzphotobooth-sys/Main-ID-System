-- ========================================
-- RFID Attendance System Database Backup
-- Generated: 2026-02-09T20:33:17.259546900
-- ========================================

SET FOREIGN_KEY_CHECKS=0;

-- Table: attendance
DROP TABLE IF EXISTS `attendance`;
CREATE TABLE `attendance` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `date` date NOT NULL,
  `time_in` time DEFAULT NULL,
  `time_out` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_attendance` (`user_id`,`date`),
  CONSTRAINT `attendance_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `attendance` VALUES
(1, 2, '2026-02-09', '20:02:41', '20:04:28');

-- Table: students
DROP TABLE IF EXISTS `students`;
CREATE TABLE `students` (
  `user_id` int NOT NULL,
  `grade` varchar(20) DEFAULT NULL,
  `section` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  CONSTRAINT `students_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `students` VALUES
(2, '11', 'ICT 201');

-- Table: users
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `user_id` int NOT NULL AUTO_INCREMENT,
  `rfid_uid` varchar(50) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `role` varchar(20) NOT NULL,
  `status` varchar(10) DEFAULT 'active',
  `photo_path` varchar(255) DEFAULT NULL,
  `parent_email` varchar(100) DEFAULT NULL,
  `birthday` date DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `rfid_uid` (`rfid_uid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO `users` VALUES
(1, '0009269290', 'System Admin', 'admin', 'active', 'photos/admin.jpg', NULL, NULL),
(2, '0009268965', 'Hermosa, Bobby Jannazer', 'student', 'active', NULL, 'bobbyvhermosa@gmail.com', '2009-09-25');


SET FOREIGN_KEY_CHECKS=1;
-- Backup completed successfully
